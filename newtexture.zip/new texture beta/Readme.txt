This 1.8.9 Texture Pack uses json to download 1.17 texture to 1.8.9 

Coded by Pickatwu

|| NOT TO COPY PASTE ||

\\ Code //

Import : { texture.json},